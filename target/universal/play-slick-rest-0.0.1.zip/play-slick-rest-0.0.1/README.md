# Fol.io-Backend


Api actual:
http://localhost:9000/vote/X/X/IDTui/X para obtener la informacion del usuario de esa ID

